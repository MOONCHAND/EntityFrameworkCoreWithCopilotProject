// export an interface from employee
export interface Employee {
    //create a few peoperties of id,name, email, phone, salary,department
    id: string;
    name: string;
    email: string;
    phone: number;
    salary: number;
    department: string;
}



